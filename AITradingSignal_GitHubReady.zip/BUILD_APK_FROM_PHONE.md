# ফোন থেকে APK Build

1. এই project-এর **সব contents** GitHub repository root-এ upload করুন।
2. নিশ্চিত করুন `.github/workflows/build-apk.yml` আছে।
3. GitHub → Actions → **Build APK** → **Run workflow**।
4. Build সফল হলে workflow run → Artifacts → **AITradingSignal-debug-apk** download করুন।
5. ZIP extract করে `app-debug.apk` install করুন।

এই সংস্করণটি signal-only demo। Quotex-এ নিজে থেকে trade/click করে না।
