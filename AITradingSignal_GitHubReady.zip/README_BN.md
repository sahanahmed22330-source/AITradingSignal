# AI Trading Signal — Overlay V2

এই version-এ Android-এর Accessibility Overlay ব্যবহার করে Quotex-এর মতো অন্য app-এর ওপর
একটি **🤖 AI floating button** এবং **AI SCANNER panel** দেখানোর ব্যবস্থা যোগ করা হয়েছে।

### ব্যবহার
1. অ্যাপ খুলুন।
2. `AI OVERLAY` চাপুন।
3. Android Accessibility settings-এ `AI Trading Signal` চালু করুন।
4. Quotex-এ ফিরে যান।
5. স্ক্রিনে `🤖 AI` floating button দেখা যাবে।
6. সেটিতে চাপলে `AI SCANNER` panel খুলবে।
7. `ANALYZE` চাপলে `UP`, `DOWN` অথবা `WAIT` দেখাবে।

### গুরুত্বপূর্ণ
এই V2-তে overlay UI বাস্তব। কিন্তু `SignalDetector.java` এখনো demo/random signal engine।
অর্থাৎ এটি এখনো Quotex-এর আসল candle পড়ে prediction করছে না।

পরের ধাপে বৈধ market-data/candle feed ও indicator calculations যোগ করতে হবে।
Quotex-এর UP/DOWN button-এ automatic click বা real-money trade execution নেই।
