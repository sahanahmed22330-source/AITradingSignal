package com.aitradingsignal;
import java.util.Random;
public class SignalDetector {
 private final Random r=new Random();
 public Signal analyze(){int x=r.nextInt(101); if(x>=70)return new Signal("UP",70+r.nextInt(25),System.currentTimeMillis()); if(x<=30)return new Signal("DOWN",70+r.nextInt(25),System.currentTimeMillis()); return new Signal("WAIT",50+r.nextInt(20),System.currentTimeMillis());}
}