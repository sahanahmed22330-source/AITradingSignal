package com.aitradingsignal;
import android.os.Bundle; import androidx.appcompat.app.AppCompatActivity;
public class HistoryActivity extends AppCompatActivity { @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_history);} }