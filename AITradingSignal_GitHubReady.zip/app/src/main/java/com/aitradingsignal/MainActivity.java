package com.aitradingsignal;
import android.content.Intent; import android.net.Uri; import android.os.Bundle; import android.provider.Settings; import android.widget.*; import androidx.appcompat.app.AppCompatActivity;
public class MainActivity extends AppCompatActivity {
 private TextView result,confidence,indicators; private final SignalDetector detector=new SignalDetector();
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
  result=findViewById(R.id.result); confidence=findViewById(R.id.confidence); indicators=findViewById(R.id.indicators);
  Spinner sp=findViewById(R.id.pairSpinner); String[] p={"EUR/USD","NZD/USD","GBP/JPY","AUD/USD","USD/CHF"}; sp.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,p));
  findViewById(R.id.analyzeButton).setOnClickListener(v->runAnalysis());
  findViewById(R.id.historyButton).setOnClickListener(v->startActivity(new Intent(this,HistoryActivity.class)));
  findViewById(R.id.overlayButton).setOnClickListener(v->openSettings());
 }
 private void runAnalysis(){Signal s=detector.analyze();result.setText(s.direction);confidence.setText("Confidence: "+s.confidence+"%");
  if(s.direction.equals("UP")){result.setTextColor(getColor(R.color.green));indicators.setText("EMA: Bullish   RSI: Strong   Momentum: Positive");}
  else if(s.direction.equals("DOWN")){result.setTextColor(getColor(R.color.red));indicators.setText("EMA: Bearish   RSI: Weak   Momentum: Negative");}
  else{result.setTextColor(getColor(R.color.text));indicators.setText("Market conditions unclear — WAIT");}}
 private void openSettings(){try{startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));}catch(Exception e){startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName())));}}
}