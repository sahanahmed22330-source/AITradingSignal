package com.aitradingsignal;

import android.accessibilityservice.AccessibilityService;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OverlayService extends AccessibilityService {
    private WindowManager wm;
    private View bubble;
    private View panel;
    private final Handler handler = new Handler();
    private final SignalDetector detector = new SignalDetector();

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        showBubble();
    }

    private WindowManager.LayoutParams params(int w, int h) {
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                w, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.END;
        p.x = 18;
        p.y = 220;
        return p;
    }

    private void showBubble() {
        if (bubble != null) return;
        Button b = new Button(this);
        b.setText("🤖 AI");
        b.setTextSize(12);
        b.setOnClickListener(v -> showPanel());

        bubble = b;
        wm.addView(bubble, params(86, 60));
    }

    private void showPanel() {
        if (panel != null) return;

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(20, 18, 20, 18);
        box.setBackgroundResource(com.aitradingsignal.R.drawable.bg_panel);

        TextView title = new TextView(this);
        title.setText("🤖 AI SCANNER");
        title.setTextColor(getColor(com.aitradingsignal.R.color.green));
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);

        TextView hint = new TextView(this);
        hint.setText("Chart selected • Tap ANALYZE");
        hint.setTextColor(getColor(com.aitradingsignal.R.color.muted));
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, 8, 0, 12);

        TextView result = new TextView(this);
        result.setText("WAIT");
        result.setTextColor(getColor(com.aitradingsignal.R.color.text));
        result.setTextSize(34);
        result.setGravity(Gravity.CENTER);
        result.setPadding(0, 10, 0, 10);

        TextView confidence = new TextView(this);
        confidence.setText("Confidence: --");
        confidence.setTextColor(getColor(com.aitradingsignal.R.color.muted));
        confidence.setGravity(Gravity.CENTER);

        Button analyze = new Button(this);
        analyze.setText("🔎 ANALYZE");
        analyze.setOnClickListener(v -> {
            Signal s = detector.analyze();
            result.setText(s.direction.equals("UP") ? "UP ↑" :
                    s.direction.equals("DOWN") ? "DOWN ↓" : "WAIT");
            if (s.direction.equals("UP"))
                result.setTextColor(getColor(com.aitradingsignal.R.color.green));
            else if (s.direction.equals("DOWN"))
                result.setTextColor(getColor(com.aitradingsignal.R.color.red));
            else
                result.setTextColor(getColor(com.aitradingsignal.R.color.text));
            confidence.setText("Confidence: " + s.confidence + "%");
        });

        Button close = new Button(this);
        close.setText("CLOSE");
        close.setOnClickListener(v -> removePanel());

        box.addView(title);
        box.addView(hint);
        box.addView(result);
        box.addView(confidence);
        box.addView(analyze);
        box.addView(close);

        panel = box;
        WindowManager.LayoutParams p = params(330, 360);
        p.x = 18;
        p.y = 300;
        wm.addView(panel, p);
    }

    private void removePanel() {
        if (panel != null) {
            wm.removeView(panel);
            panel = null;
        }
    }

    @Override
    public void onAccessibilityEvent(android.view.accessibility.AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {}

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (panel != null) wm.removeView(panel);
        if (bubble != null) wm.removeView(bubble);
        panel = null;
        bubble = null;
    }
}
